import com.sap.gateway.ip.core.customdev.util.Message
import java.security.MessageDigest
import java.math.BigInteger

def Message processData(Message message) {
    String linesString = message.getProperty("v_body_file") ?: ""
    String[] lines = linesString.split("\\n")
    String md5 = ""

    try {
        MessageDigest md = MessageDigest.getInstance("MD5")
        StringBuilder sb = new StringBuilder()
        lines.each { line ->
            sb.append(line).append("\r\n")
        }
        // Log do texto que será convertido em bytes
        messageLogFactory.getMessageLog(message)?.addAttachmentAsString("TextToDigest", sb.toString(), "text/plain")

        byte[] bytesToDigest = sb.toString().getBytes("UTF-8")
        // Log do array de bytes tamanho para verificar validade
        messageLogFactory.getMessageLog(message)?.addAttachmentAsString("BytesLength", bytesToDigest.length.toString(), "text/plain")

        byte[] digest = md.digest(bytesToDigest)

        md5 = new BigInteger(1, digest).toString(16).toUpperCase()
        md5 = md5.padLeft(32, '0') // padding para garantir 32 chars

    } catch (Exception e) {
        // Log completo da exceção para entender o erro
        messageLogFactory.getMessageLog(message)?.addAttachmentAsString("Exception", e.toString() + "\n" + e.stackTrace.join("\n"), "text/plain")
        throw e // re-levanta para que o erro apareça no log do iFlow
    }

    message.setHeader("v_MD5_Hash", md5)
    return message
}
