import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*

def Message processData(Message message) {
    
    // lê payload como String
    def body = message.getBody(String)
    
    // faz parse do XML
    def xml = new XmlSlurper().parseText(body)
    
    // inicializa um StringBuilder para montar o arquivo
    def sb = new StringBuilder()
    
    // percorre cada linha
    xml.line.each { line ->
        // pega o conteúdo da tag <content>
        def content = line.content.text()
        
        // adiciona uma linha no arquivo (com quebra de linha padrão Unix)
        sb.append(content).append("\n")
    }
    
    // define novo body como texto puro
    message.setBody(sb.toString())
    
    return message
}