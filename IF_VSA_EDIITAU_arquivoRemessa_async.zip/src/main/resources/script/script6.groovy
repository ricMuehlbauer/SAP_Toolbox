import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Printing Payload, Headers e Properties");
        
        // Log do Body
        messageLog.addAttachmentAsString("ResponsePayload:", body, "text/plain");
        
        // Log de todos os Headers
        def headers = message.getHeaders();
        def headersStr = headers.collect { k, v -> "${k}: ${v}" }.join("\n");
        messageLog.addAttachmentAsString("AllHeaders:", headersStr, "text/plain");
        
        // Log de todas as Properties
        def properties = message.getProperties();
        def propertiesStr = properties.collect { k, v -> "${k}: ${v}" }.join("\n");
        messageLog.addAttachmentAsString("AllProperties:", propertiesStr, "text/plain");
    }
    return message;
}
