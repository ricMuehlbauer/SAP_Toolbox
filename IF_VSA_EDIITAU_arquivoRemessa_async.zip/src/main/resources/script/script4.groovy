import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat

def Message processData(Message message) {

    // ==========================
    // Entrada
    // ==========================
    def headers = message.getHeaders()
    String varAmbiente = headers.get("v_tp_exec", String)
    String varFileName = varAmbiente + headers.get("v_filename", String)
    String varDir = headers.get("v_diretorio", String)
    String varDirAux
    String varTipoDoc
    String varCodTrib
    String varFileNameAux = ""

    // Data e hora
    def now = new Date()
    def MMDD   = new SimpleDateFormat("ddMM").format(now)
    def hhmmss = new SimpleDateFormat("HHmmss").format(now)

    // ==========================
    // Dados iniciais
    // ==========================
    varDirAux   = varFileName.substring(1, 5)   // Empresa
    
    // ==========================
    // Ajuste código tributário
    // ==========================
    varCodTrib = varFileName.substring(10, 12)

    if (varCodTrib == "11") {
        int varTamStr = varFileName.length()
        varCodTrib = "PAG"
        varFileName = varFileName.substring(0, 10) +
                      varCodTrib +
                      varFileName.substring(17, varTamStr)
    }

    // ==========================
    // Tipo de documento
    // ==========================
    varTipoDoc = varFileName.substring(10, 13)

    if (varTipoDoc == "PAG" || varFileName.contains("_1_PAG")) {
        varTipoDoc = "008"
    }

    if (varTipoDoc == "COB") {
        varTipoDoc = "001"
    }

    if (!varTipoDoc) {
        varTipoDoc = "008"
    }

    // ==========================
    // Diretório base
    // ==========================
    if (varAmbiente == "P") {
        varDir = "/VOTO${varDirAux}/REMESSA/PROD/${varTipoDoc}/"
    } else {
        varDir = "/VOTO${varDirAux}/REMESSA/TESTE/${varTipoDoc}/"
    }

    // ==========================
    // Remessa folha
    // ==========================
    if (varFileName.contains("_9_") ||
        varFileName.contains("_1_") ||
        varFileName.contains("_F_")) {

        varTipoDoc = "008"

        // Arquivo iniciando com FP
        if (varFileName.substring(1, 3) == "FP") {
            varDirAux = varFileName.substring(3, 7)

                if (varAmbiente == "P") {
                    varDir = "/VOTO${varDirAux}/REMESSA/PROD/${varTipoDoc}/"
                } else {
                    varDir = "/VOTO${varDirAux}/REMESSA/TESTE/${varTipoDoc}/"
                }
        }
    }

    // ==========================
    // Nome final do arquivo
    // ==========================
    if (!varTipoDoc?.trim()) {
        varDir = "ERROR"
    } else {
        varFileNameAux = "${varAmbiente}${varTipoDoc}${MMDD}${hhmmss}.REM"
    }

    // ==========================
    // Headers do File Adapter
    // ==========================
    message.setProperty("v_fname", varFileNameAux)
    message.setProperty("v_dir", varDir)

    return message
}
