import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Lê o header de entrada
    def headers = message.getHeaders();
    def arqOrig = headers.get("v_onlyname");
    def arqOrigEmpresa = headers.get("v_onlyname");      
    if (arqOrig == null) arqOrig = ""

    def tpArq = ""
    def resultBanco = ""
    def resultEmpresa = ""

    if (arqOrig.length() >= 2) {
        tpArq = arqOrig.substring(0, 2)
        
        if (tpArq == "HT") {
            // cuidado para não extrapolar limites da string
            if (arqOrig.length() >= 9) {
                resultBanco = arqOrig.substring(6, 9)
            } else {
                resultBanco = ""
            }
        } else {
            if (arqOrig.length() >= 8) {
                resultBanco = arqOrig.substring(5, 8)
            } else {
                resultBanco = ""
            }
        }
    } else {
        resultBanco = ""
    }

    if (arqOrigEmpresa.length() >= 2) {
        tpArq = arqOrigEmpresa.substring(0, 2)

        if (tpArq == "HT") {
            if (arqOrigEmpresa.length() >= 6) {
                resultEmpresa = arqOrigEmpresa.substring(2, 6)
            } else {
                resultEmpresa = ""
            }
        } else {
            if (arqOrigEmpresa.length() >= 4) {
                resultEmpresa = arqOrigEmpresa.substring(0, 4)
            } else {
                resultEmpresa = ""
            }
        }
    } else {
        resultEmpresa = ""
    }

    // Define o resultado no property v_filename_new
    message.setProperty("v_banco", resultBanco)
    message.setProperty("v_empresa", resultEmpresa)
    return message
}