import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    try {
        // Lê o header v_filename (equivalente ao conf.get(key1) do PI)
        def varFileName = message.getHeader("v_filename", String) ?: ""
        
        if (varFileName.length() < 4) {
            message.setProperty("v_tpdoc", "")
            return message
        }
        
        // Extrai tipo documento (posições 1-3, zero-based: 1-4)
        def varTipoDoc = varFileName.substring(1, 4)
        
        // Mapeamento reverso (números → códigos)
        switch (varTipoDoc) {
            case "004": varTipoDoc = "VVI"; break
            case "008": varTipoDoc = "PAG"; break
            case "001": varTipoDoc = "COB"; break
            case "025": varTipoDoc = "EXT"; break
            case "042": varTipoDoc = "DDA"; break
            case "215": varTipoDoc = "FDC"; break
            case "184": varTipoDoc = "RIS"; break
            case "033": varTipoDoc = "TED"; break
            case "012": varTipoDoc = "PIX"; break
        }
        
        // Regra especial folha de pagamento
        if (varFileName.substring(0, 2) == "FP" && varFileName.indexOf("_9_") >= 0) {
            varTipoDoc = "FPG"
        }
        
        // Salva resultado no property (equivalente ao return da UDF)
        message.setProperty("V_STCP_TP_OPER", varTipoDoc)
        
       // v_STCP_COMP_CODE
        def vAbsolutePath = message.getHeader("v_absolute_path", String) ?: ""
        
        if (vAbsolutePath) {
            def vDiretorio = ""
           //// if (vAbsolutePath.startsWith("/QAS")) {
         ////       vDiretorio = vAbsolutePath.substring(4, 8)  // /QAS/XXXX → XXXX
         ////   } else {
                vDiretorio = vAbsolutePath.substring(4, 8)  // /XXXX/ → XXXX
         ////   }
            message.setProperty("v_STCP_COMP_CODE", vDiretorio)
        } else {
            message.setProperty("v_STCP_COMP_CODE", "")
        }        
        
        
    } catch (Exception e) {
        message.setProperty("V_STCP_TP_OPER", "ERRO: " + e.message)
    }
    
    return message
}
