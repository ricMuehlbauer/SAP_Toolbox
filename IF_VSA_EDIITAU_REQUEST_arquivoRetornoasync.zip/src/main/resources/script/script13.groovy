import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.DocumentBuilder
import java.io.ByteArrayInputStream

def Message processData(Message message) {
    def messageLog = messageLogFactory?.getMessageLog(message)
    
    try {
        // 1) Tipo de operação vindo do Property V_STCP_TP_OPER
        def varTipoDoc = message.getProperty("V_STCP_TP_OPER") ?: ""
        // 1.1) Tipo de operação vindo do Property v_STCP_COMP_CODE
        def varCompCode = message.getProperty("v_STCP_COMP_CODE") ?: ""

        // 2) Mapeia para o código usado no nome do arquivo
        def codigoTpDoc = ""
        switch(varTipoDoc) {
            case "VVI": codigoTpDoc = "_4_"; break
            case "PAG": codigoTpDoc = "_1_"; break
            case "COB": codigoTpDoc = "_2_"; break
            case "EXT": codigoTpDoc = "_3_"; break
            case "DDA": codigoTpDoc = "_5_"; break
            case "FDC": codigoTpDoc = "_8_"; break
            case "RIS": codigoTpDoc = "_1_"; break
            case "FPG": codigoTpDoc = "_9_"; break
            case "TED": codigoTpDoc = "_98_"; break
            case "PIX": codigoTpDoc = "_99_"; break
            default:    codigoTpDoc = "_0_"; break
        }

        // 3) Filename original vindo do HEADER v_filename
        def varFileName = message.getHeader("v_filename", String) ?: "UNKNOWN"
        def prefixoFile = varFileName.length() >= 14 ? varFileName.substring(0, 14) : varFileName

        // 4) Monta o filename final
        def v_filename_final = varCompCode + "_341" + codigoTpDoc + "RET_" + prefixoFile + ".RET"
        v_filename_final = v_filename_final.replace("..RET", ".RET")
        message.setProperty("v_filename_final", v_filename_final)

          // 5) Lê XML do body e pega DIRETORIO do item (CPI com XmlSlurper)
        def body = message.getBody(String)
        def diretorioRaw = ""

        if (body?.trim()) {
            if (messageLog) {
                messageLog.addAttachmentAsString("XML_RAW", body, "text/xml")
            }

            def xml = new XmlSlurper().parseText(body)
            diretorioRaw = xml.T_ZTBFI_CHAMADAS.item.DIRETORIO.text()?.trim() ?: ""
        }

        // 6) Extrai dinamicamente DIRETORIO (2º ':' + 3 chars) e monta final
        def diretorio = ""
        if (diretorioRaw) {
            def secondColonIndex = diretorioRaw.indexOf(':', diretorioRaw.indexOf(':') + 1)
            if (secondColonIndex != -1) {
                diretorio = diretorioRaw.substring(secondColonIndex + 3)
            } else {
                diretorio = diretorioRaw  // fallback
            }
        }

message.setHeader("diretorio", diretorio)

        def v_diretorio_final = ""
        if (diretorio) {
            if (!varTipoDoc.equals("FPG")) {
                v_diretorio_final = "edi" + diretorio
            } else {
                v_diretorio_final = diretorio
            }
        } else {
            v_diretorio_final = "edi/default"
        }

        message.setProperty("v_diretorio_final", v_diretorio_final)
        

    } catch (Exception e) {
        if (messageLog) {
            messageLog.addAttachmentAsString("ERRO GERAL", e.message, "text/plain")
        }
        message.setProperty("v_filename_final", "filenameERROR")
        message.setProperty("v_diretorio_final", "directoryERROR")
    }

    return message
}
