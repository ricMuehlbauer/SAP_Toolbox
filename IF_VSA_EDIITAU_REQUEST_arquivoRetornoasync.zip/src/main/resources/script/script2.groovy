import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String) as String;
    def messageLog = messageLogFactory.getMessageLog(message);
    
    if(messageLog != null){
        messageLog.setStringProperty("Logging#1", "Payload + Headers logged as attachments");
        
        // Payload como antes
        messageLog.addAttachmentAsString("Payload:", body, "text/plain");
        
        // Headers como novo attachment
        def headers = message.getHeaders();
        def headersText = headers.collect { key, value -> "${key}: ${value}" }.join("\n");
        messageLog.addAttachmentAsString("Headers:", headersText, "text/plain");
    }
    return message;
}
