import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    try {
        // Lê o corpo como byte array (equivalente ao InputStream no PI)
        def bodyBytes = message.getBody(byte[])
        
        // Converte para String UTF-8
        def inputString = new String(bodyBytes, "UTF-8")
        
        // Substitui \x00 (null bytes/carriage return) por espaço (equivalente ao replaceAll do Java)
        def cleanedString = inputString.replaceAll("\\u0000", " ")
        
        // Converte de volta para byte array UTF-8 e define como novo body
        def outputBytes = cleanedString.getBytes("UTF-8")
        message.setBody(outputBytes)
        
        return message
    } catch (Exception e) {
        throw new Exception("Erro no processamento: " + e.getMessage())
    }
}
