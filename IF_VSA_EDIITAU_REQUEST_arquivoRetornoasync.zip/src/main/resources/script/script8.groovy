import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.*
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.DocumentBuilder
import java.io.ByteArrayInputStream

def Message processData(Message message) {
    def messageLog = messageLogFactory?.getMessageLog(message)
    
    try {
        // 1) Tipo de operação vindo do Property V_STCP_TP_OPER
        def varTipoDoc = message.getProperty("V_STCP_TP_OPER") ?: ""
        
        // 2) Mapeia para o código usado no nome do arquivo
        def codigoTpDoc = ""
        switch(varTipoDoc) {
            case "VVI": codigoTpDoc = "_4_"; break
            case "PAG": codigoTpDoc = "_1_"; break
            case "COB": codigoTpDoc = "_2_"; break
            case "EXT": codigoTpDoc = "_3_"; break
            case "DDA": codigoTpDoc = "_5_"; break
            case "FDC": codigoTpDoc = "_8_"; break
            case "RIS": codigoTpDoc = "_1_"; break
            case "FPG": codigoTpDoc = "_9_"; break
            case "TED": codigoTpDoc = "_98_"; break
            case "PIX": codigoTpDoc = "_99_"; break
            default:    codigoTpDoc = "_0_"; break
        }

        // 3) Filename original vindo do HEADER v_filename
        def varFileName = message.getHeader("v_filename", String) ?: "UNKNOWN"
        def prefixoFile = varFileName.length() >= 18 ? varFileName.substring(0, 18) : varFileName

        // 4) Monta o filename final
        def v_filename_final = prefixoFile + "_341" + codigoTpDoc + "RET" + ".RET"
        v_filename_final = v_filename_final.replace("..RET", ".RET")
        message.setProperty("v_filename_final", v_filename_final)

        // 5) Lê XML do body e pega DIRETORIO do item (DOM corrigido)
        def body = message.getBody(String)
        def diretorioRaw = ""
        
        if (messageLog && body?.trim()) {
            messageLog.addAttachmentAsString("XML_RAW", body, "text/xml")
            
            def factory = DocumentBuilderFactory.newInstance()
            def builder = factory.newDocumentBuilder()
            def is = new ByteArrayInputStream(body.getBytes("UTF-8"))
            def doc = builder.parse(is)
            def nl = doc.getElementsByTagName("item")
            
            if (nl.length > 0) {
                def node = nl.item(0)
                def children = node.getChildNodes()
                
                // Procura tag DIRETORIO (ignora text nodes)
                for (int i = 0; i < children.length; i++) {
                    def child = children.item(i)
                    if (child.nodeType == 1 && "DIRETORIO".equals(child.nodeName)) {  // ELEMENT_NODE
                        diretorioRaw = child.textContent ?: ""
                        break
                    }
                }
            }
        }

        // 6) Extrai dinamicamente DIRETORIO (2º ':' + 3 chars) e monta final
        def diretorio = ""
        if (diretorioRaw) {
            def secondColonIndex = diretorioRaw.indexOf(':', diretorioRaw.indexOf(':') + 1)
            if (secondColonIndex != -1) {
                diretorio = diretorioRaw.substring(secondColonIndex + 3)
            } else {
                diretorio = diretorioRaw  // fallback
            }
        }

        def v_diretorio_final = ""
        if (diretorio) {
            if (!varTipoDoc.equals("FPG")) {
                v_diretorio_final = "edi" + diretorio
            } else {
                v_diretorio_final = diretorio
            }
        } else {
            v_diretorio_final = "edi/default"
        }

        message.setProperty("v_diretorio_final", v_diretorio_final)
        
        if (messageLog) {
            messageLog.addAttachmentAsString(
                "Resultado Final", 
                "Input: v_filename=${varFileName}, V_STCP_TP_OPER=${varTipoDoc}\n" +
                "XML DIRETORIO raw: ${diretorioRaw}\n" +
                "Processado diretorio: ${diretorio}\n" +
                "v_filename_final: ${v_filename_final}\n" +
                "v_diretorio_final: ${v_diretorio_final}", 
                "text/plain"
            )
        }

    } catch (Exception e) {
        if (messageLog) {
            messageLog.addAttachmentAsString("ERRO GERAL", e.message, "text/plain")
        }
        message.setProperty("v_filename_final", "filenameERROR")
        message.setProperty("v_diretorio_final", "directoryERROR")
    }

    return message
}
