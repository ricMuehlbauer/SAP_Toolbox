import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Calendar

def Message processData(Message message) {
    try {
        // Lê o header v_filename_ambiente
        def varFileName = message.getHeader("v_absolute_path", String) ?: ""
        def varFileName2 = message.getHeader("v_filename", String) ?: ""

        if (varFileName.length() < 13) {
            message.setProperty("v_filename_new", "")
            return message
        }
        
        // Extrai variáveis conforme UDF original
        def varAmbiente = varFileName2.substring(0, 1)
        def empresa = varFileName.substring(4, 8)
        def varTipoDoc = varFileName.substring(22, 25)
        
        // Mapeamento de tipos de documento
        switch (varTipoDoc) {
            case "PAG": varTipoDoc = "008"; break
            case "COB": varTipoDoc = "001"; break
            case "EXT": varTipoDoc = "025"; break
            case "TED": varTipoDoc = "033"; break
            case "PIX": varTipoDoc = "PIX"; break
        }
        
        // Timestamp corrigido GMT-3: Calendar com TZ desde início + SDF com TZ
        def tz = TimeZone.getTimeZone("GMT-3")  // Ou "America/Sao_Paulo" para BRT
        def cal = Calendar.getInstance(tz)  // Instancia com TZ
        def sdf = new SimpleDateFormat("MMddHHmmss")
        sdf.setTimeZone(tz)  // Reforça no formatter
        def timestamp = sdf.format(cal.getTime())
        
        // Nome base do arquivo
        def newFileName = "${empresa}_341_${varAmbiente}${varTipoDoc}${timestamp}.RET"
        
        // Regras especiais sobrepostas
        switch (varTipoDoc) {
            case "RIS":
                varTipoDoc = "RETRIS"
                newFileName = "${empresa}_1_${varAmbiente}${varTipoDoc}${cal.get(Calendar.YEAR)}${timestamp}.RET"
                break
            case "VVI":
                varTipoDoc = "RETDDA"
                newFileName = "${empresa}_341_${varAmbiente}${varTipoDoc}${cal.get(Calendar.YEAR)}${timestamp}.RET"
                break
            case "FDC":
                varTipoDoc = "RETFDC"
                newFileName = "${empresa}_341_${varAmbiente}${varTipoDoc}${cal.get(Calendar.YEAR)}${timestamp}.RET"
                break
            case "042":
                varTipoDoc = "RETDDA"
                newFileName = "${empresa}_341_${varAmbiente}${varTipoDoc}${cal.get(Calendar.YEAR)}${timestamp}.RET"
                break
        }
        
        // Define o novo nome do arquivo no property
        message.setProperty("v_filename_new", newFileName)
        
 
    } catch (Exception e) {
        message.setProperty("v_filename_new", "ERRO: " + e.message)
    }
    
    return message
}
