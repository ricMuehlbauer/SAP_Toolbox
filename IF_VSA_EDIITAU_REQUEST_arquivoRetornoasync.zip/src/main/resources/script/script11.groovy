import com.sap.gateway.ip.core.customdev.util.Message;
def Message processData(Message message) {
    //Body
    //def body = message.getBody();
    /*To set the body, you can use the following method. Refer SCRIPT APIs document for more detail*/
    //message.setBody(body + " Body is modified");
    
    // Properties (Exchange Properties)
    def properties = message.getProperties();
    def v_diretorio_final = properties.get("v_diretorio_final");
 
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null){
        if(v_diretorio_final != null){
            messageLog.addCustomHeaderProperty("Path", v_diretorio_final);
        }    
    }  
    return message;
}
