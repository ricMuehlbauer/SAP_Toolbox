import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap; 
import com.sap.aii.mapping.api.*; 

def Message processData(Message message) {
	
	String dynamicJavaMapping = message.getProperty("DynamicJavaMapping");
	
    def javaMapping = this.class.classLoader.loadClass(dynamicJavaMapping, true, false)?.newInstance();
	
	String resultString;
	
	if (javaMapping.metaClass.methods*.name.contains("transform")){
		MyTransformationInput  transformationInput  = new MyTransformationInput(message);
		MyTransformationOutput transformationOutput = new MyTransformationOutput();
		
		def result = javaMapping.transform(transformationInput,transformationOutput);
		
		resultString = new String(transformationOutput.getOutputPayload().getOutputStream().toByteArray());
	}else{
		InputStream inputStream = new ByteArrayInputStream( body.getBytes( 'UTF-8' ) );
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		
		def result = javaMappingPayloadNamespace.execute(inputStream,outputStream);
		
		resultString = new String(outputStream.toByteArray());	
	}
	  
    message.setBody(resultString);
    
    return message;
}

class MyTransformationInput extends TransformationInput {
    
    private MyInputPayload inputPayload;
    
    MyTransformationInput(Message message){
        inputPayload = new MyInputPayload(message);
    }
    
    @Override
    InputPayload getInputPayload() {  
        return inputPayload;   
    }
    
    @Override
    InputHeader getInputHeader() {}

    @Override
    InputParameters getInputParameters() {}

    @Override
    InputAttachments getInputAttachments() {}
 
    @Override
    DynamicConfiguration getDynamicConfiguration() {}
}

class MyInputPayload extends InputPayload {
    private InputStream input;
    
    MyInputPayload(Message message){
        def body = message.getBody(java.lang.String) as String;
        input = new ByteArrayInputStream( body.getBytes( 'UTF-8' ) );
    }
    
    @Override
    InputStream getInputStream() {  
        return input;
    }
}

class MyTransformationOutput extends TransformationOutput {
    
    private MyOutputPayload outputPayload;
    
    MyTransformationOutput(){
        outputPayload = new MyOutputPayload();
    }
    
    @Override
    OutputPayload getOutputPayload() {  
        return outputPayload;   
    }
    
    @Override
    OutputHeader getOutputHeader() {}

    @Override
    OutputParameters getOutputParameters() {}

    @Override
    OutputAttachments getOutputAttachments() {}
 
    @Override
    void copyInputAttachments() {}
}

class MyOutputPayload extends OutputPayload {
    private ByteArrayOutputStream output;
    
    MyOutputPayload(){
        output = new ByteArrayOutputStream();
    }
    
    @Override
    OutputStream getOutputStream() {  
        return output;
    }
}


class MyInputHeader extends InputHeader { 
    private String sapMessageID;
	
    MyInputHeader(Message message){ 
		sapMessageID = message.getProperty("SAP_MessageProcessingLogID");
    }
    
    @Override
    String getMessageId() {  
        return sapMessageID;
    }
	
	@Override
    String get(String name) {}
	
	@Override
    Map<String, String> getAll() {}
	
	@Override
    String getConversationId() {}
	
	@Override
    String getInterface() {}
	
	@Override
    String getInterfaceNamespace() {}
	
	@Override
    String getMessageClass() {}
	
	@Override
    String getProcessingMode() {}
	
	@Override
    String getReceiverInterface() {}
	
	@Override
    String getReceiverInterfaceNamespace() {}
	
	@Override
    String getReceiverParty() {}
	
	@Override
    String getReceiverPartyAgency() {}
	
	@Override
    String getReceiverPartyScheme() {}
	
	@Override
    String getReceiverService() {}
	
	@Override
    String getRefToMessageId() {}
	
	@Override
    String getSenderInterface() {}
	
	@Override
    String getSenderInterfaceNamespace() {}
	
	@Override
    String getSenderParty() {}
	
	@Override
    String getSenderPartyScheme() {}
	
	@Override
    String getSenderParytAgency() {}
	
	@Override
    String getSenderService() {}
	
	@Override
    String getTimeSent() {}
	
	@Override
    String getVersionMajor() {}
	
	@Override
    String getVersionMinor() {}
	
}