import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Pega o header vFile
    def vFile= message.getHeader("v_absolute_path", String) ?: ""

    // Pega o header vFile
    def vFilename_banco = message.getHeader("v_filename", String) ?: ""
    
    // Pega o header v_ambiente
    def vAmbiente = message.getHeader("v_ambiente", String) ?: ""    
    
    // Concatena vFile + vAmbiente para criar v_filename_ambiente
    def vFilenAmbiente = vFile + vAmbiente 
    message.setProperty("v_filename_ambiente", vFilenAmbiente)    
    
    // Pega os primeiros 5 caracteres (com segurança)
    def prefix5 = vFile.substring(4, Math.min(8, vFile.length()))
    
    // Salva como propriedade para uso posterior
    message.setProperty("v_empresa", prefix5)
    
    
    // v_tpdoc: caracteres 10-13 (posição 9-12, zero-based)
    def vTpdoc = ""
    vTpdoc = vFile.substring(23, 26)  // 10º ao 13º char (9-12 index)
    message.setProperty("v_tpdoc", vTpdoc)    
    
    
    // v_banco: caracteres 6-9 (posição 5-8, zero-based)
    //def vBanco = ""
    vBanco = vFilename_banco.substring(5, 8)  
    message.setProperty("v_banco", vBanco)     

    return message
}
