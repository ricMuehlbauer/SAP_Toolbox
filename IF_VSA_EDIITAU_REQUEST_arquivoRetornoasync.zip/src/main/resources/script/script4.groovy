import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper

def Message processData(Message message) {
    try {
        // Lê o corpo da mensagem (retorno RFC T_ZTBFI_CHAMADAS)
        def body = message.getBody(String)
        
        // Parse XML com XmlSlurper
        def xml = new XmlSlurper().parseText(body)
        
        // Busca todos os <item> da tabela T_ZTBFI_CHAMADAS
        def items = xml.'**'.findAll { it.name() == 'item' }
        
        def diretorio = ""
        
        items.each { item ->
            // Extrai os 6 campos específicos na ordem exata
            def tp_oper = item.TP_OPER?.text()?.trim()
            def comp_code = item.COMP_CODE?.text()?.trim()
            def cod_solicit = item.COD_SOLICIT?.text()?.trim()
            def cnpj = item.CNPJ?.text()?.trim()
            def cod_convenio = item.COD_CONVENIO?.text()?.trim()
            def diretorio_raw = item.DIRETORIO?.text()?.trim()
            
            // Log dos valores (equivalente ao trace do PI)
            def messageLog = messageLogFactory.getMessageLog(message)
            messageLog.addAttachmentAsString("T_ZTBFI_CHAMADAS", 
                "TP_OPER: ${tp_oper}\nCOMP_CODE: ${comp_code}\nCOD_SOLICIT: ${cod_solicit}\nCNPJ: ${cnpj}\nCOD_CONVENIO: ${cod_convenio}\nDIRETORIO: ${diretorio_raw}", 
                "text/plain")
            
            // Só processa se DIRETORIO não estiver vazio
            if (diretorio_raw && !diretorio_raw.isEmpty()) {
                // Aplica a mesma lógica: "/edi" + substring(34)
                diretorio = "/edi" + diretorio_raw.substring(34)
                
                // Salva todos os campos como propriedades (útil para roteamento)
                message.setProperty("TP_OPER", tp_oper)
                message.setProperty("COMP_CODE", comp_code)
                message.setProperty("COD_SOLICIT", cod_solicit)
                message.setProperty("CNPJ", cnpj)
                message.setProperty("COD_CONVENIO", cod_convenio)
                message.setProperty("v_diretorio", diretorio)
                
                // Headers para File Adapter
                message.setHeader("SAP_Directory", diretorio)
                message.setHeader("CamelFileName", "${comp_code}_${cod_solicit}.txt")
            }
        }
        
        messageLog.addAttachmentAsString("DiretorioFinal", diretorio, "text/plain")
        return message
        
    } catch (Exception e) {
        def messageLog = messageLogFactory.getMessageLog(message)
        messageLog.addAttachmentAsString("Erro_T_ZTBFI_CHAMADAS", e.getMessage(), "text/plain")
        throw new Exception("Erro processando T_ZTBFI_CHAMADAS: " + e.getMessage())
    }
}
